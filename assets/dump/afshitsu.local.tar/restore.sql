--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE afshitsu;
--
-- Name: afshitsu; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE afshitsu WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE afshitsu OWNER TO postgres;

\connect afshitsu

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: compteLocalEntropyFor(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."compteLocalEntropyFor"(character varying) RETURNS TABLE(idcharacter character varying, avg_probability numeric, entropy numeric)
    LANGUAGE sql
    AS $_$ 
SELECT
"idcharacter",
AVG ("probability") "avg_probability",
 -- the bigger the entropy the bigger the info we have at hand in the database
SUM ("probability" * "local_info") "entropy"
FROM
"getAllProbaByIdChara" ($1)
GROUP BY
"idcharacter"
$_$;


ALTER FUNCTION public."compteLocalEntropyFor"(character varying) OWNER TO postgres;

--
-- Name: getAllProbaByIdChara(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."getAllProbaByIdChara"(character varying) RETURNS TABLE(idcharacter character varying, idquestion character varying, content text, idanswer character varying, probability numeric, local_info numeric)
    LANGUAGE sql
    AS $_$ 
SELECT
$1 "idcharacter",
"Question"."idquestion",
"Question"."content",
"temp"."idanswer", -- can be null
COALESCE("temp"."probability", 0.5) "probability",
 -LOG(GREATEST(COALESCE("temp"."probability", 0.5), 0.0001))/LOG(2) "local_info"
FROM
"Question" LEFT JOIN (SELECT * FROM "Answer" WHERE "idcharacter" = $1) AS "temp"
ON "Question"."idquestion" = "temp"."idquestion"; 
$_$;


ALTER FUNCTION public."getAllProbaByIdChara"(character varying) OWNER TO postgres;

--
-- Name: answerSeq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."answerSeq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."answerSeq" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Answer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Answer" (
    idanswer character varying(50) DEFAULT concat('ANS_', nextval('public."answerSeq"'::regclass)) NOT NULL,
    probability numeric,
    idquestion character varying(50) NOT NULL,
    idcharacter character varying(20) NOT NULL
);


ALTER TABLE public."Answer" OWNER TO postgres;

--
-- Name: characterSeq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."characterSeq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."characterSeq" OWNER TO postgres;

--
-- Name: Character; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Character" (
    idcharacter character varying(50) DEFAULT concat('CHR_', nextval('public."characterSeq"'::regclass)) NOT NULL,
    name character varying(120) NOT NULL,
    image character varying(120),
    play_count integer DEFAULT 0 NOT NULL,
    submitted_by character varying(20) DEFAULT 'X'::character varying NOT NULL,
    submit_time timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Character" OWNER TO postgres;

--
-- Name: feedbackSeq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."feedbackSeq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."feedbackSeq" OWNER TO postgres;

--
-- Name: Feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Feedback" (
    idfeedback character varying(50) DEFAULT concat('FDB_', nextval('public."feedbackSeq"'::regclass)) NOT NULL,
    pseudo character varying(20) NOT NULL,
    content text NOT NULL
);


ALTER TABLE public."Feedback" OWNER TO postgres;

--
-- Name: questionSeq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."questionSeq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."questionSeq" OWNER TO postgres;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Question" (
    idquestion character varying(50) DEFAULT concat('QST_', nextval('public."questionSeq"'::regclass)) NOT NULL,
    content text NOT NULL,
    weight integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."Question" OWNER TO postgres;

--
-- Name: v_CharaAnswer; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CharaAnswer" AS
 SELECT "Character".idcharacter,
    "Character".name,
    "Character".play_count,
    "Character".submitted_by,
    COALESCE("Answer".probability, (0)::numeric) AS probability,
    "Answer".idquestion
   FROM (public."Character"
     LEFT JOIN public."Answer" ON ((("Answer".idcharacter)::text = ("Character".idcharacter)::text)));


ALTER TABLE public."v_CharaAnswer" OWNER TO postgres;

--
-- Name: v_CharaQuestionAnswer; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CharaQuestionAnswer" AS
 SELECT "v_CharaAnswer".idcharacter,
    "v_CharaAnswer".name,
    "v_CharaAnswer".play_count,
    "v_CharaAnswer".submitted_by,
    "v_CharaAnswer".probability,
    "v_CharaAnswer".idquestion,
    "Question".content,
    "Question".weight
   FROM (public."v_CharaAnswer"
     LEFT JOIN public."Question" ON ((("Question".idquestion)::text = ("v_CharaAnswer".idquestion)::text)))
  ORDER BY "v_CharaAnswer".probability DESC;


ALTER TABLE public."v_CharaQuestionAnswer" OWNER TO postgres;

--
-- Name: v_CorrespondsToQuestion; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CorrespondsToQuestion" AS
 SELECT "v_CharaAnswer".idcharacter,
    "v_CharaAnswer".name,
    "v_CharaAnswer".play_count,
    "v_CharaAnswer".submitted_by,
    "v_CharaAnswer".probability,
    "v_CharaAnswer".idquestion
   FROM public."v_CharaAnswer"
  WHERE ("v_CharaAnswer".probability > 0.5);


ALTER TABLE public."v_CorrespondsToQuestion" OWNER TO postgres;

--
-- Name: v_CountForQuestionRIGHT; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CountForQuestionRIGHT" AS
 SELECT "v_CorrespondsToQuestion".idquestion,
    count(*) AS possibility
   FROM public."v_CorrespondsToQuestion"
  GROUP BY "v_CorrespondsToQuestion".idquestion;


ALTER TABLE public."v_CountForQuestionRIGHT" OWNER TO postgres;

--
-- Name: v_CountPossibilityForQuestion; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CountPossibilityForQuestion" AS
 SELECT "Question".idquestion,
    "Question".content,
    COALESCE("v_CountForQuestionRIGHT".possibility, (0)::bigint) AS possibility
   FROM (public."Question"
     LEFT JOIN public."v_CountForQuestionRIGHT" ON ((("Question".idquestion)::text = ("v_CountForQuestionRIGHT".idquestion)::text)));


ALTER TABLE public."v_CountPossibilityForQuestion" OWNER TO postgres;

--
-- Name: v_CountPossibilityNoZero; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_CountPossibilityNoZero" AS
 SELECT "v_CountPossibilityForQuestion".idquestion,
    "v_CountPossibilityForQuestion".content,
    "v_CountPossibilityForQuestion".possibility
   FROM public."v_CountPossibilityForQuestion"
  WHERE ("v_CountPossibilityForQuestion".possibility > 0);


ALTER TABLE public."v_CountPossibilityNoZero" OWNER TO postgres;

--
-- Name: v_QSTCountCHR; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."v_QSTCountCHR" AS
 SELECT "Question".idquestion,
    "Question".content,
    "Question".weight,
    count("Answer".idanswer) AS related_chr_count,
    avg("Answer".probability) AS avg_probability
   FROM (public."Question"
     LEFT JOIN public."Answer" ON ((("Question".idquestion)::text = ("Answer".idquestion)::text)))
  GROUP BY "Question".idquestion, "Question".content, "Question".weight
  ORDER BY (count("Answer".idanswer)) DESC, "Question".weight DESC, (avg("Answer".probability)) DESC;


ALTER TABLE public."v_QSTCountCHR" OWNER TO postgres;

--
-- Data for Name: Answer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Answer" (idanswer, probability, idquestion, idcharacter) FROM stdin;
\.
COPY public."Answer" (idanswer, probability, idquestion, idcharacter) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: Character; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Character" (idcharacter, name, image, play_count, submitted_by, submit_time) FROM stdin;
\.
COPY public."Character" (idcharacter, name, image, play_count, submitted_by, submit_time) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: Feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Feedback" (idfeedback, pseudo, content) FROM stdin;
\.
COPY public."Feedback" (idfeedback, pseudo, content) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Question" (idquestion, content, weight) FROM stdin;
\.
COPY public."Question" (idquestion, content, weight) FROM '$$PATH$$/3063.dat';

--
-- Name: answerSeq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."answerSeq"', 1441, true);


--
-- Name: characterSeq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."characterSeq"', 60, true);


--
-- Name: feedbackSeq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."feedbackSeq"', 1, false);


--
-- Name: questionSeq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."questionSeq"', 184, true);


--
-- Name: Answer Answer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_pkey" PRIMARY KEY (idanswer);


--
-- Name: Character Character_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Character"
    ADD CONSTRAINT "Character_pkey" PRIMARY KEY (idcharacter);


--
-- Name: Feedback Feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_pkey" PRIMARY KEY (idfeedback);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (idquestion);


--
-- Name: Answer Answer_idcharacter_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_idcharacter_fkey" FOREIGN KEY (idcharacter) REFERENCES public."Character"(idcharacter);


--
-- Name: Answer Answer_idquestion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_idquestion_fkey" FOREIGN KEY (idquestion) REFERENCES public."Question"(idquestion);


--
-- PostgreSQL database dump complete
--

